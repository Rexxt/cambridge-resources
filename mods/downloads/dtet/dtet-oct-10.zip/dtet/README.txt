DTET Rotation System mod for Cambridge by Mizu (Rexxt on Github)
New Cambridge by MillaBasset (SashLilac on Github)
======================================================================================================================================================
This mod (currently in development) adds DRS (DTET Rotation System) to Cambridge.
Latest update on October 10th, 2020. This mod wasn't tested with Cambridge 0.2.0. Please let me know if it works or not.
======================================================================================================================================================
To install this mod, simply drag the "dtet" lua file in \tetris\rulesets and the "mode_select" lua file in \scene\.
======================================================================================================================================================
This mod can be downloaded using Cambridge Launcher 0.2.0 and up. The new version of the launcher supports downloading and launching mods.
Please remember to frequently update the launcher and the mod.